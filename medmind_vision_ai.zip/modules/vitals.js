navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
        const video = document.getElementById('video');
        video.srcObject = stream;
        simulateVitals();
    });

function simulateVitals() {
    const heartRate = Math.floor(Math.random() * 40) + 60;
    const respRate = Math.floor(Math.random() * 10) + 12;
    document.getElementById('heartRate').innerText = heartRate;
    document.getElementById('respRate').innerText = respRate;
}
