function getAnswer() {
    const question = document.getElementById('question').value;
    fetch('data/medical_qa.json')
        .then(response => response.json())
        .then(data => {
            let answer = "抱歉，未能找到相關答案。";
            for (let item of data) {
                if (question.includes(item.question)) {
                    answer = item.answer;
                    break;
                }
            }
            document.getElementById('answer').innerText = answer;
        });
}

function generateSuggestion() {
    const heartRate = parseInt(document.getElementById('heartRate').innerText);
    const respRate = parseInt(document.getElementById('respRate').innerText);
    let suggestion = "請先啟動生命體徵分析。";
    if (!isNaN(heartRate) && !isNaN(respRate)) {
        suggestion = "您的生命體徵屬於正常範圍。請保持良好生活習慣。";
        if (heartRate > 100 || respRate > 20) {
            suggestion = "您的心跳或呼吸速率偏高，建議休息並觀察是否有不適。";
        }
    }
    document.getElementById('suggestion').innerText = suggestion;
}
